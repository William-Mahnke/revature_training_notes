# Databricks notebook source
# MAGIC %md
# MAGIC # RetailPulse - 00 Setup
# MAGIC
# MAGIC Creates a schema and managed Unity Catalog volume.
# MAGIC Run this notebook first, then upload the three CSV files into the volume.

# COMMAND ----------

CATALOG = spark.sql("SELECT current_catalog()").first()[0]
SCHEMA = "retail_fresher"
VOLUME = "retail_raw"

spark.sql(f"CREATE SCHEMA IF NOT EXISTS `{CATALOG}`.`{SCHEMA}`")
spark.sql(
    f"CREATE VOLUME IF NOT EXISTS `{CATALOG}`.`{SCHEMA}`.`{VOLUME}`"
)

BASE_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"

print(f"Current catalog : {CATALOG}")
print(f"Schema          : {SCHEMA}")
print(f"Volume          : {VOLUME}")
print(f"Upload path     : {BASE_PATH}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Upload files
# MAGIC
# MAGIC In the Databricks workspace:
# MAGIC
# MAGIC 1. Open **New → Add or upload data**.
# MAGIC 2. Select **Upload files to a volume**.
# MAGIC 3. Choose the volume created above.
# MAGIC 4. Upload:
# MAGIC    - `customers_500.csv`
# MAGIC    - `products_500.csv`
# MAGIC    - `sales_orders_500.csv`
