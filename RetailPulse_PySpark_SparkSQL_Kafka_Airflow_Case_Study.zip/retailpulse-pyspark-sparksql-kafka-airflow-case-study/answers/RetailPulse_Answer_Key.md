# RetailPulse Case Study — Answer Key

## Architecture

```text
Three CSV files
      ↓
Databricks Bronze managed Delta tables
      ↓
PySpark Silver transformations
      ↓
PySpark and Spark SQL Gold summaries
      ↓
Gold Kafka event table / JSONL file
      ↓
Kafka producer → retail-sales-summary topic
      ↓
Kafka consumer
      ↓
Airflow weekly orchestration
```

## Expected control totals

| Check | Expected |
|---|---:|
| Customer input rows | 500 |
| Unique customers after latest-record deduplication | 490 |
| Active customers after deduplication | 461 |
| Product input rows | 500 |
| Active products with valid price and cost | 469 |
| Order input rows | 500 |
| Enriched financial sales rows after filters and joins | 377 |
| Month-category Gold rows | 30 |
| Net sales total | 3582186.25 |

## Main solution files

### Databricks

1. `00_Setup_RetailPulse.py`
2. `01_Bronze_Ingestion.py`
3. `02_PySpark_Silver_Gold.py`
4. `03_Spark_SQL_Analysis.py`
5. `04_Create_Kafka_Events.py`

### Kafka

- `retail_event_producer.py`
- `retail_event_consumer.py`

### Airflow

- `retailpulse_weekly_orchestration.py`

## PySpark transformation answers

### Filter

```python
orders_silver = orders_silver.filter(F.col("quantity") > 0)
orders_silver = orders_silver.filter(
    F.col("order_status").isin("COMPLETED", "RETURNED")
)
```

### Change data type

```python
.withColumn("quantity", F.col("quantity").cast("int"))
.withColumn("order_timestamp", F.to_timestamp("order_timestamp"))
.withColumn("unit_price", F.col("unit_price").cast("decimal(12,2)"))
```

### Add columns

```python
.withColumn(
    "gross_amount",
    F.round(F.col("quantity") * F.col("unit_price"), 2)
)
.withColumn(
    "discount_amount",
    F.round(
        F.col("gross_amount") * F.col("discount_pct") / 100,
        2
    )
)
.withColumn(
    "net_amount",
    F.round(F.col("gross_amount") - F.col("discount_amount"), 2)
)
```

### Deduplication window

```python
window_spec = (
    Window
    .partitionBy("customer_id")
    .orderBy(F.to_timestamp("updated_at").desc())
)

customers = (
    customers
    .withColumn("profile_rank", F.row_number().over(window_spec))
    .filter(F.col("profile_rank") == 1)
)
```

### Aggregation

```python
monthly_sales = (
    sales_enriched
    .groupBy("order_month", "category")
    .agg(
        F.countDistinct("order_id").alias("order_count"),
        F.sum("quantity").alias("total_quantity"),
        F.round(F.sum("net_sales"), 2).alias("total_revenue")
    )
)
```

### Product ranking

```python
rank_window = (
    Window
    .partitionBy("category")
    .orderBy(F.col("product_revenue").desc())
)

top_products = (
    product_revenue
    .withColumn("product_rank", F.rank().over(rank_window))
    .filter(F.col("product_rank") <= 5)
)
```

## Spark SQL answer pattern

```sql
SELECT
  order_month,
  category,
  COUNT(DISTINCT order_id) AS order_count,
  SUM(quantity) AS total_quantity,
  ROUND(SUM(net_sales), 2) AS total_revenue
FROM sql_sales_enriched
GROUP BY order_month, category;
```

## Kafka answer

The producer sends one JSON event for every row in
`gold_kafka_events`. The event key is `event_id`; the topic is
`retail-sales-summary`.

The consumer uses a consumer group, starts from the earliest offset for a new
group, prints the event, and stores it in JSONL format.

## Airflow answer

```python
schedule="0 9 * * 3"
catchup=False
```

The `DatabricksRunNowOperator` starts an existing Databricks job. The next task
queries the Gold event table through the Databricks SQL connector, writes JSONL,
publishes events to Kafka and consumes five sample events.

## Expected learning outcome

The trainee demonstrates one connected batch-and-event workflow rather than
four unrelated demos. PySpark performs DataFrame transformations, Spark SQL
recreates important analytics, Kafka distributes the resulting business event,
and Airflow coordinates execution on a schedule.
