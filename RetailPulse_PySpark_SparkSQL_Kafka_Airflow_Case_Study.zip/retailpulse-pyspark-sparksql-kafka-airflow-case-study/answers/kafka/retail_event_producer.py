from __future__ import annotations

import argparse
import json
from pathlib import Path

from confluent_kafka import Producer


def delivery_report(error, message) -> None:
    if error is not None:
        print(f"Delivery failed: {error}")
    else:
        print(
            f"Delivered key={message.key().decode('utf-8')} "
            f"to {message.topic()}[{message.partition()}] "
            f"offset={message.offset()}"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap-servers", default="localhost:9092")
    parser.add_argument("--topic", default="retail-sales-summary")
    parser.add_argument("--input-file", required=True)
    args = parser.parse_args()

    input_path = Path(args.input_file)
    if not input_path.exists():
        raise FileNotFoundError(input_path)

    producer = Producer({
        "bootstrap.servers": args.bootstrap_servers,
        "client.id": "retailpulse-summary-producer",
        "enable.idempotence": True,
        "acks": "all",
    })

    sent = 0
    with input_path.open("r", encoding="utf-8") as source:
        for line in source:
            line = line.strip()
            if not line:
                continue
            event = json.loads(line)
            producer.produce(
                topic=args.topic,
                key=event["event_id"].encode("utf-8"),
                value=json.dumps(event).encode("utf-8"),
                callback=delivery_report,
            )
            producer.poll(0)
            sent += 1

    producer.flush()
    print(f"Published {sent} events to {args.topic}")


if __name__ == "__main__":
    main()
