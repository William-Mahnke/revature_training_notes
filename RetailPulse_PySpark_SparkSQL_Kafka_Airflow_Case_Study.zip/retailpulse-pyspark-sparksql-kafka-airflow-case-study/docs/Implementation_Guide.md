# RetailPulse — End-to-End Implementation Sequence

## Recommended classroom duration

| Day | Work |
|---|---|
| Day 1 | Databricks setup, upload files, Bronze ingestion |
| Day 2 | PySpark cleaning, casts, joins and derived columns |
| Day 3 | Aggregations, window functions and Spark SQL |
| Day 4 | Kafka producer and consumer |
| Day 5 | Airflow scheduling, monitoring and final demonstration |

## Part 1 — Databricks Free Edition

### Create or open the workspace

Use Databricks Free Edition for notebook, SQL and job practice.

### Import the notebooks

Import these files in order:

1. `00_Setup_RetailPulse.py`
2. `01_Bronze_Ingestion.py`
3. `02_PySpark_Silver_Gold.py`
4. `03_Spark_SQL_Analysis.py`
5. `04_Create_Kafka_Events.py`

Databricks Python source notebooks contain:

```text
# Databricks notebook source
# COMMAND ----------
```

### Create the schema and volume

Run notebook 00.

It creates:

```text
Current catalog
└── retail_fresher
    └── retail_raw volume
```

### Upload data

Use:

```text
New
→ Add or upload data
→ Upload files to a volume
```

Upload the three CSV files to the volume created by notebook 00.

### Execute the notebooks

Run notebook 01 through notebook 04.

Expected controls:

```text
Customers input                     : 500
Unique customer IDs                 : 490
Active customers                    : 461
Products input                      : 500
Active valid products               : 469
Orders input                        : 500
Final enriched financial sales rows : 377
Gold month-category rows            : 30
Net sales total                     : 3582186.25
```

### Create a Databricks Job

Create a job containing four sequential notebook tasks:

```text
Bronze ingestion
→ PySpark Silver/Gold
→ Spark SQL analysis
→ Kafka event creation
```

Copy the Job ID for Airflow.

## Part 2 — Kafka

Create the topic:

```text
retail-sales-summary
```

Download `kafka_events.jsonl` from the Databricks volume export folder.

Install the Python client:

```bash
pip install -r requirements.txt
```

Run the consumer first in Terminal 1:

```bash
python retail_event_consumer.py   --bootstrap-servers localhost:9092   --max-messages 30
```

Run the producer in Terminal 2:

```bash
python retail_event_producer.py   --input-file kafka_events.jsonl   --bootstrap-servers localhost:9092
```

## Part 3 — Airflow

Install:

```bash
pip install   apache-airflow-providers-databricks   databricks-sql-connector   "confluent-kafka>=2.5,<3"
```

Create the `databricks_default` Airflow connection.

Set the required environment variables described in:

```text
answers/airflow/README.md
```

Copy:

```text
retailpulse_weekly_orchestration.py
```

to the Airflow DAG folder.

The schedule is:

```text
0 9 * * 3
```

This represents Wednesday at 09:00 in the DAG timezone.

## Final demonstration

Show:

1. Three input datasets.
2. Bronze tables.
3. Silver and Gold tables.
4. PySpark window-function results.
5. Spark SQL comparison query.
6. Kafka producer delivery logs.
7. Kafka consumer messages.
8. Airflow Graph view.
9. Successful Wednesday-scheduled DAG.
10. Control-total validation.
