# Databricks notebook source
# MAGIC %md
# MAGIC # RetailPulse - 04 Create Kafka Events
# MAGIC
# MAGIC Converts Gold summary rows to JSON events and writes one JSONL file to
# MAGIC the Unity Catalog volume.

# COMMAND ----------

from pyspark.sql import functions as F
import json
from pathlib import Path

CATALOG = spark.sql("SELECT current_catalog()").first()[0]
SCHEMA = "retail_fresher"
VOLUME = "retail_raw"
BASE_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"

summary_df = spark.read.table(
    f"{CATALOG}.{SCHEMA}.gold_monthly_category_sales"
)

# COMMAND ----------

events_df = (
    summary_df
    .select(
        F.concat(
            F.lit("SALES-"),
            F.col("order_month"),
            F.lit("-"),
            F.regexp_replace(F.col("category"), " ", "_")
        ).alias("event_id"),
        F.lit("MONTHLY_CATEGORY_SALES_READY").alias("event_type"),
        F.current_timestamp().alias("event_time"),
        "order_month",
        "category",
        "order_count",
        "total_quantity",
        "total_revenue",
        "average_order_value",
    )
)

(
    events_df.write
    .mode("overwrite")
    .option("overwriteSchema", True)
    .saveAsTable(f"{CATALOG}.{SCHEMA}.gold_kafka_events")
)

display(events_df.orderBy("order_month", "category"))

# COMMAND ----------

# The event table is small, so collecting it for one JSONL export is safe.
event_lines = events_df.toJSON().collect()

export_folder = Path(f"{BASE_PATH}/exports")
export_folder.mkdir(parents=True, exist_ok=True)

export_file = export_folder / "kafka_events.jsonl"
export_file.write_text("\n".join(event_lines) + "\n", encoding="utf-8")

print(f"Kafka event file created: {export_file}")
print(f"Event count: {len(event_lines)}")
