from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

from confluent_kafka import Consumer, KafkaError


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--bootstrap-servers", default="localhost:9092")
    parser.add_argument("--topic", default="retail-sales-summary")
    parser.add_argument("--group-id", default="retailpulse-summary-consumer")
    parser.add_argument("--output-file", default="consumed_events.jsonl")
    parser.add_argument("--max-messages", type=int, default=30)
    parser.add_argument("--timeout-seconds", type=int, default=30)
    args = parser.parse_args()

    consumer = Consumer({
        "bootstrap.servers": args.bootstrap_servers,
        "group.id": args.group_id,
        "auto.offset.reset": "earliest",
        "enable.auto.commit": False,
    })

    consumer.subscribe([args.topic])
    output_path = Path(args.output_file)

    count = 0
    started = time.time()

    try:
        with output_path.open("w", encoding="utf-8") as target:
            while count < args.max_messages:
                if time.time() - started > args.timeout_seconds:
                    print("Consumer timeout reached.")
                    break

                message = consumer.poll(1.0)
                if message is None:
                    continue

                if message.error():
                    if message.error().code() == KafkaError._PARTITION_EOF:
                        continue
                    raise RuntimeError(message.error())

                event = json.loads(message.value().decode("utf-8"))
                print(json.dumps(event, indent=2))
                target.write(json.dumps(event) + "\n")
                count += 1

            consumer.commit(asynchronous=False)
    finally:
        consumer.close()

    print(f"Consumed {count} events into {output_path}")


if __name__ == "__main__":
    main()
