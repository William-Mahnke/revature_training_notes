from __future__ import annotations

import json
import os
import time
from pathlib import Path

import pendulum
from confluent_kafka import Consumer, KafkaError, Producer
from databricks import sql

from airflow.sdk import DAG
from airflow.providers.databricks.operators.databricks import (
    DatabricksRunNowOperator,
)
from airflow.providers.standard.operators.empty import EmptyOperator
from airflow.providers.standard.operators.python import PythonOperator


EVENT_FILE = Path(
    os.environ.get(
        "RETAIL_EVENT_FILE",
        str(Path.home() / "retailpulse_airflow" / "kafka_events.jsonl"),
    )
)

DATABRICKS_JOB_ID = int(os.environ["DATABRICKS_JOB_ID"])
DATABRICKS_SERVER_HOSTNAME = os.environ["DATABRICKS_SERVER_HOSTNAME"]
DATABRICKS_HTTP_PATH = os.environ["DATABRICKS_HTTP_PATH"]
DATABRICKS_TOKEN = os.environ["DATABRICKS_TOKEN"]

KAFKA_BOOTSTRAP_SERVERS = os.environ.get(
    "KAFKA_BOOTSTRAP_SERVERS",
    "localhost:9092",
)
KAFKA_TOPIC = os.environ.get(
    "KAFKA_TOPIC",
    "retail-sales-summary",
)


def export_gold_events() -> int:
    EVENT_FILE.parent.mkdir(parents=True, exist_ok=True)

    statement = """
    SELECT
      event_id,
      event_type,
      CAST(event_time AS STRING) AS event_time,
      order_month,
      category,
      order_count,
      total_quantity,
      total_revenue,
      average_order_value
    FROM retail_fresher.gold_kafka_events
    ORDER BY order_month, category
    """

    rows = []
    with sql.connect(
        server_hostname=DATABRICKS_SERVER_HOSTNAME,
        http_path=DATABRICKS_HTTP_PATH,
        access_token=DATABRICKS_TOKEN,
    ) as connection:
        with connection.cursor() as cursor:
            cursor.execute(statement)
            columns = [item[0] for item in cursor.description]
            for row in cursor.fetchall():
                rows.append(dict(zip(columns, row)))

    with EVENT_FILE.open("w", encoding="utf-8") as target:
        for row in rows:
            target.write(json.dumps(row, default=str) + "\n")

    print(f"Exported {len(rows)} events to {EVENT_FILE}")
    return len(rows)


def publish_events() -> int:
    producer = Producer({
        "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
        "client.id": "airflow-retailpulse-producer",
        "enable.idempotence": True,
        "acks": "all",
    })

    count = 0
    with EVENT_FILE.open("r", encoding="utf-8") as source:
        for line in source:
            event = json.loads(line)
            producer.produce(
                KAFKA_TOPIC,
                key=event["event_id"].encode("utf-8"),
                value=json.dumps(event).encode("utf-8"),
            )
            producer.poll(0)
            count += 1

    producer.flush()
    print(f"Published {count} Kafka events.")
    return count


def consume_sample_events() -> int:
    consumer = Consumer({
        "bootstrap.servers": KAFKA_BOOTSTRAP_SERVERS,
        "group.id": f"airflow-retailpulse-{int(time.time())}",
        "auto.offset.reset": "earliest",
        "enable.auto.commit": False,
    })

    consumer.subscribe([KAFKA_TOPIC])
    count = 0
    started = time.time()

    try:
        while count < 5 and time.time() - started < 30:
            message = consumer.poll(1.0)
            if message is None:
                continue
            if message.error():
                if message.error().code() == KafkaError._PARTITION_EOF:
                    continue
                raise RuntimeError(message.error())

            print(message.value().decode("utf-8"))
            count += 1
    finally:
        consumer.close()

    print(f"Consumed {count} sample events.")
    return count


with DAG(
    dag_id="retailpulse_weekly_orchestration",
    description="Run Databricks retail ETL and publish Gold events to Kafka.",
    schedule="0 9 * * 3",
    start_date=pendulum.datetime(2026, 1, 1, tz="Asia/Kolkata"),
    catchup=False,
    max_active_runs=1,
    tags=["databricks", "pyspark", "spark-sql", "kafka", "training"],
) as dag:
    start = EmptyOperator(task_id="start")

    run_databricks_job = DatabricksRunNowOperator(
        task_id="run_databricks_job",
        databricks_conn_id="databricks_default",
        job_id=DATABRICKS_JOB_ID,
        polling_period_seconds=20,
        wait_for_termination=True,
    )

    export_events = PythonOperator(
        task_id="export_gold_events",
        python_callable=export_gold_events,
    )

    publish = PythonOperator(
        task_id="publish_events_to_kafka",
        python_callable=publish_events,
    )

    consume = PythonOperator(
        task_id="consume_sample_events",
        python_callable=consume_sample_events,
    )

    finish = EmptyOperator(task_id="finish")

    start >> run_databricks_job >> export_events >> publish >> consume >> finish
