# Kafka commands

## Create topic on Windows

```bat
C:\kafka43\bin\windows\kafka-topics.bat ^
  --create ^
  --if-not-exists ^
  --topic retail-sales-summary ^
  --bootstrap-server localhost:9092 ^
  --partitions 3 ^
  --replication-factor 1
```

## Create topic on Linux

```bash
bin/kafka-topics.sh \
  --create \
  --if-not-exists \
  --topic retail-sales-summary \
  --bootstrap-server localhost:9092 \
  --partitions 3 \
  --replication-factor 1
```

## Run producer

```bash
python retail_event_producer.py \
  --input-file kafka_events.jsonl \
  --bootstrap-servers localhost:9092
```

## Run consumer

```bash
python retail_event_consumer.py \
  --bootstrap-servers localhost:9092 \
  --max-messages 30
```
