# Databricks notebook source
# MAGIC %md
# MAGIC # RetailPulse - 02 PySpark Silver and Gold
# MAGIC
# MAGIC Demonstrates filter, cast, derived columns, joins, aggregations and
# MAGIC window functions.

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import DecimalType

CATALOG = spark.sql("SELECT current_catalog()").first()[0]
SCHEMA = "retail_fresher"

customers_raw = spark.read.table(f"{CATALOG}.{SCHEMA}.bronze_customers")
products_raw = spark.read.table(f"{CATALOG}.{SCHEMA}.bronze_products")
orders_raw = spark.read.table(f"{CATALOG}.{SCHEMA}.bronze_sales_orders")

# COMMAND ----------

# Customer cleaning and deduplication.
customer_window = (
    Window
    .partitionBy("customer_id")
    .orderBy(F.to_timestamp("updated_at").desc())
)

customers_silver = (
    customers_raw
    .withColumn("customer_id", F.upper(F.trim("customer_id")))
    .withColumn("customer_name", F.initcap(F.trim("customer_name")))
    .withColumn("email", F.lower(F.trim("email")))
    .withColumn(
        "city",
        F.when(F.trim("city") == "", F.lit("Unknown"))
         .otherwise(F.initcap(F.trim("city")))
    )
    .withColumn("signup_date", F.to_date("signup_date"))
    .withColumn("date_of_birth", F.to_date("date_of_birth"))
    .withColumn("updated_at", F.to_timestamp("updated_at"))
    .withColumn("loyalty_points", F.col("loyalty_points").cast("int"))
    .withColumn("profile_rank", F.row_number().over(customer_window))
    .filter(F.col("profile_rank") == 1)
    .filter(F.col("is_active") == "Y")
    .withColumn(
        "customer_age",
        F.floor(F.months_between(F.lit("2026-08-01"), "date_of_birth") / 12)
    )
    .withColumn(
        "customer_tenure_days",
        F.datediff(F.lit("2026-08-01"), "signup_date")
    )
    .drop("profile_rank")
)

print("Customer unique active rows:", customers_silver.count())

# COMMAND ----------

# Product cleaning.
products_silver = (
    products_raw
    .withColumn("product_id", F.upper(F.trim("product_id")))
    .withColumn("product_name", F.initcap(F.trim("product_name")))
    .withColumn("category", F.initcap(F.trim("category")))
    .withColumn("unit_price", F.col("unit_price").cast(DecimalType(12, 2)))
    .withColumn("cost_price", F.col("cost_price").cast(DecimalType(12, 2)))
    .withColumn("stock_quantity", F.col("stock_quantity").cast("int"))
    .withColumn("launch_date", F.to_date("launch_date"))
    .withColumn("product_rating", F.col("product_rating").cast("double"))
    .filter(F.col("active_flag") == "Y")
    .filter(F.col("unit_price").isNotNull())
    .filter(F.col("cost_price").isNotNull())
    .withColumn("profit_per_unit", F.col("unit_price") - F.col("cost_price"))
    .withColumn(
        "profit_margin_pct",
        F.round(
            (F.col("profit_per_unit") / F.col("unit_price")) * 100,
            2
        )
    )
    .withColumn(
        "stock_value",
        F.round(F.col("stock_quantity") * F.col("cost_price"), 2)
    )
    .withColumn(
        "stock_status",
        F.when(F.col("stock_quantity") == 0, "OUT_OF_STOCK")
         .when(F.col("stock_quantity") < 25, "LOW_STOCK")
         .otherwise("AVAILABLE")
    )
)

print("Product active valid rows:", products_silver.count())

# COMMAND ----------

# Order cleaning.
orders_silver = (
    orders_raw
    .withColumn("order_id", F.upper(F.trim("order_id")))
    .withColumn("customer_id", F.upper(F.trim("customer_id")))
    .withColumn("product_id", F.upper(F.trim("product_id")))
    .withColumn("order_timestamp", F.to_timestamp("order_timestamp"))
    .withColumn("quantity", F.col("quantity").cast("int"))
    .withColumn(
        "discount_pct",
        F.coalesce(F.col("discount_pct").cast("double"), F.lit(0.0))
    )
    .withColumn("promised_delivery_date", F.to_date("promised_delivery_date"))
    .withColumn("actual_delivery_date", F.to_date("actual_delivery_date"))
    .filter(F.col("quantity") > 0)
    .filter(F.col("order_status").isin("COMPLETED", "RETURNED"))
    .withColumn("order_date", F.to_date("order_timestamp"))
    .withColumn("order_month", F.date_format("order_timestamp", "yyyy-MM"))
    .withColumn(
        "delivery_days",
        F.datediff("actual_delivery_date", "order_date")
    )
    .withColumn(
        "late_delivery_flag",
        F.when(
            F.col("actual_delivery_date") > F.col("promised_delivery_date"),
            "Y"
        ).otherwise("N")
    )
)

print("Valid financial orders before joins:", orders_silver.count())

# COMMAND ----------

sales_enriched = (
    orders_silver.alias("o")
    .join(
        customers_silver.alias("c"),
        F.col("o.customer_id") == F.col("c.customer_id"),
        "inner",
    )
    .join(
        products_silver.alias("p"),
        F.col("o.product_id") == F.col("p.product_id"),
        "inner",
    )
    .select(
        F.col("o.order_id"),
        F.col("o.order_timestamp"),
        F.col("o.order_date"),
        F.col("o.order_month"),
        F.col("o.customer_id"),
        F.col("c.customer_name"),
        F.col("c.city"),
        F.col("c.state"),
        F.col("c.region"),
        F.col("c.customer_segment"),
        F.col("o.product_id"),
        F.col("p.product_name"),
        F.col("p.category"),
        F.col("p.subcategory"),
        F.col("o.quantity"),
        F.col("p.unit_price"),
        F.col("p.cost_price"),
        F.col("o.discount_pct"),
        F.col("o.order_status"),
        F.col("o.payment_method"),
        F.col("o.sales_channel"),
        F.col("o.delivery_days"),
        F.col("o.late_delivery_flag"),
    )
    .withColumn(
        "gross_amount",
        F.round(F.col("quantity") * F.col("unit_price"), 2)
    )
    .withColumn(
        "discount_amount",
        F.round(
            F.col("gross_amount") * F.col("discount_pct") / 100,
            2
        )
    )
    .withColumn(
        "net_amount",
        F.round(F.col("gross_amount") - F.col("discount_amount"), 2)
    )
    .withColumn(
        "net_sales",
        F.when(
            F.col("order_status") == "RETURNED",
            -F.col("net_amount")
        ).otherwise(F.col("net_amount"))
    )
    .withColumn(
        "profit_amount",
        F.round(
            F.col("net_sales") -
            (F.col("quantity") * F.col("cost_price")),
            2
        )
    )
)

print("Final enriched sales rows:", sales_enriched.count())
display(sales_enriched.limit(20))

# COMMAND ----------

# Save Silver managed Delta tables.
for name, dataframe in {
    "silver_customers": customers_silver,
    "silver_products": products_silver,
    "silver_sales_orders": orders_silver,
    "silver_sales_enriched": sales_enriched,
}.items():
    (
        dataframe.write
        .mode("overwrite")
        .option("overwriteSchema", True)
        .saveAsTable(f"{CATALOG}.{SCHEMA}.{name}")
    )

# COMMAND ----------

# Aggregations.
gold_monthly_category_sales = (
    sales_enriched
    .groupBy("order_month", "category")
    .agg(
        F.countDistinct("order_id").alias("order_count"),
        F.sum("quantity").alias("total_quantity"),
        F.round(F.sum("net_sales"), 2).alias("total_revenue"),
        F.round(F.avg("net_amount"), 2).alias("average_order_value"),
        F.round(F.min("net_amount"), 2).alias("minimum_order_value"),
        F.round(F.max("net_amount"), 2).alias("maximum_order_value"),
    )
)

gold_city_sales = (
    sales_enriched
    .groupBy("state", "city")
    .agg(
        F.countDistinct("order_id").alias("order_count"),
        F.round(F.sum("net_sales"), 2).alias("total_revenue"),
        F.round(F.avg("net_amount"), 2).alias("average_order_value"),
    )
)

gold_customer_value = (
    sales_enriched
    .groupBy(
        "customer_id", "customer_name", "state", "customer_segment"
    )
    .agg(
        F.countDistinct("order_id").alias("order_count"),
        F.round(F.sum("net_sales"), 2).alias("customer_revenue"),
        F.max("order_timestamp").alias("latest_order_timestamp"),
    )
)

# COMMAND ----------

# Window functions.
product_revenue = (
    sales_enriched
    .groupBy("category", "product_id", "product_name")
    .agg(F.round(F.sum("net_sales"), 2).alias("product_revenue"))
)

product_rank_window = (
    Window
    .partitionBy("category")
    .orderBy(F.col("product_revenue").desc())
)

gold_top_products = (
    product_revenue
    .withColumn("product_rank", F.rank().over(product_rank_window))
    .filter(F.col("product_rank") <= 5)
)

customer_rank_window = (
    Window
    .partitionBy("state")
    .orderBy(F.col("customer_revenue").desc())
)

customer_ranked = (
    gold_customer_value
    .withColumn(
        "customer_rank_in_state",
        F.dense_rank().over(customer_rank_window)
    )
)

latest_order_window = (
    Window
    .partitionBy("customer_id")
    .orderBy(F.col("order_timestamp").desc())
)

latest_order_per_customer = (
    sales_enriched
    .withColumn(
        "latest_order_rank",
        F.row_number().over(latest_order_window)
    )
    .filter(F.col("latest_order_rank") == 1)
)

running_window = (
    Window
    .partitionBy("category")
    .orderBy("order_month")
    .rowsBetween(Window.unboundedPreceding, Window.currentRow)
)

monthly_running_revenue = (
    gold_monthly_category_sales
    .withColumn(
        "running_category_revenue",
        F.round(F.sum("total_revenue").over(running_window), 2)
    )
)

# COMMAND ----------

# Save Gold tables.
for name, dataframe in {
    "gold_monthly_category_sales": gold_monthly_category_sales,
    "gold_city_sales": gold_city_sales,
    "gold_customer_value": customer_ranked,
    "gold_top_products": gold_top_products,
    "gold_latest_customer_order": latest_order_per_customer,
    "gold_monthly_running_revenue": monthly_running_revenue,
}.items():
    (
        dataframe.write
        .mode("overwrite")
        .option("overwriteSchema", True)
        .saveAsTable(f"{CATALOG}.{SCHEMA}.{name}")
    )

display(gold_monthly_category_sales.orderBy("order_month", "category"))
display(gold_top_products.orderBy("category", "product_rank"))
