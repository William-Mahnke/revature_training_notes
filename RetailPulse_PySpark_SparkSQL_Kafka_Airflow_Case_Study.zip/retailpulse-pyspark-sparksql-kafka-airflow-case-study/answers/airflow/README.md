# Airflow Setup

## Schedule

```text
0 9 * * 3
```

This runs every Wednesday at 09:00 in the DAG timezone.

For a fixed interval of every two days, use a timetable or
`datetime.timedelta(days=2)` rather than the cron expression `*/2` in the
day-of-month field.

## Create the Databricks job

Create one Databricks job with these notebook tasks in order:

1. `01_Bronze_Ingestion`
2. `02_PySpark_Silver_Gold`
3. `03_Spark_SQL_Analysis`
4. `04_Create_Kafka_Events`

Copy its Job ID.

## Install dependencies

```bash
source ~/airflow_food_delivery_lab/.venv/bin/activate

pip install \
  apache-airflow-providers-databricks \
  databricks-sql-connector \
  "confluent-kafka>=2.5,<3"
```

## Airflow Databricks connection

Create a connection named:

```text
databricks_default
```

Set:

```text
Connection type: Databricks
Host: https://YOUR-WORKSPACE-HOST
Token/password: YOUR-WORKSPACE-TOKEN
```

Do not put the token in the DAG source.

## Environment variables

```bash
export DATABRICKS_JOB_ID="123456789"
export DATABRICKS_SERVER_HOSTNAME="your-workspace-host"
export DATABRICKS_HTTP_PATH="/sql/1.0/warehouses/your-warehouse-id"
export DATABRICKS_TOKEN="your-token"
export KAFKA_BOOTSTRAP_SERVERS="localhost:9092"
export KAFKA_TOPIC="retail-sales-summary"
```

Copy the DAG into `$AIRFLOW_HOME/dags`, restart Airflow, and unpause it.

## Simple fallback

When workspace API/token automation is unavailable, schedule the four
Databricks notebook tasks using Databricks Jobs and use Airflow only for the
local Kafka publish/consume portion. The learning outcomes remain the same,
but the fully integrated Airflow-to-Databricks trigger is the preferred
extension.
