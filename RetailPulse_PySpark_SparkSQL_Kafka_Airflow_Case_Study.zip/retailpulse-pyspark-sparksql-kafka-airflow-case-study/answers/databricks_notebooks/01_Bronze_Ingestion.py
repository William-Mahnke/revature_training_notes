# Databricks notebook source
# MAGIC %md
# MAGIC # RetailPulse - 01 Bronze Ingestion
# MAGIC
# MAGIC Loads the three CSV files as strings and writes managed Delta tables.

# COMMAND ----------

from pyspark.sql import functions as F

CATALOG = spark.sql("SELECT current_catalog()").first()[0]
SCHEMA = "retail_fresher"
VOLUME = "retail_raw"
BASE_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/{VOLUME}"
TABLE_PREFIX = f"`{CATALOG}`.`{SCHEMA}`"

# COMMAND ----------

def load_csv_as_strings(file_name: str):
    return (
        spark.read
        .option("header", True)
        .option("inferSchema", False)
        .option("mode", "PERMISSIVE")
        .csv(f"{BASE_PATH}/{file_name}")
        .withColumn("source_file", F.lit(file_name))
        .withColumn("ingestion_timestamp", F.current_timestamp())
    )

customers_bronze = load_csv_as_strings("customers_500.csv")
products_bronze = load_csv_as_strings("products_500.csv")
orders_bronze = load_csv_as_strings("sales_orders_500.csv")

# COMMAND ----------

print("Customer input rows:", customers_bronze.count())
print("Product input rows :", products_bronze.count())
print("Order input rows   :", orders_bronze.count())

customers_bronze.printSchema()
products_bronze.printSchema()
orders_bronze.printSchema()

# COMMAND ----------

(
    customers_bronze.write
    .mode("overwrite")
    .option("overwriteSchema", True)
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_customers")
)

(
    products_bronze.write
    .mode("overwrite")
    .option("overwriteSchema", True)
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_products")
)

(
    orders_bronze.write
    .mode("overwrite")
    .option("overwriteSchema", True)
    .saveAsTable(f"{CATALOG}.{SCHEMA}.bronze_sales_orders")
)

# COMMAND ----------

display(spark.read.table(f"{CATALOG}.{SCHEMA}.bronze_customers").limit(10))
display(spark.read.table(f"{CATALOG}.{SCHEMA}.bronze_products").limit(10))
display(spark.read.table(f"{CATALOG}.{SCHEMA}.bronze_sales_orders").limit(10))
