# Databricks notebook source
# MAGIC %md
# MAGIC # RetailPulse - 03 Spark SQL Analysis

# COMMAND ----------

CATALOG = spark.sql("SELECT current_catalog()").first()[0]
SCHEMA = "retail_fresher"

spark.sql(f"USE CATALOG `{CATALOG}`")
spark.sql(f"USE SCHEMA `{SCHEMA}`")

print(f"Using {CATALOG}.{SCHEMA}")

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   order_status,
# MAGIC   COUNT(*) AS row_count
# MAGIC FROM bronze_sales_orders
# MAGIC GROUP BY order_status
# MAGIC ORDER BY row_count DESC;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE sql_sales_enriched AS
# MAGIC WITH customer_latest AS
# MAGIC (
# MAGIC   SELECT *
# MAGIC   FROM
# MAGIC   (
# MAGIC     SELECT
# MAGIC       UPPER(TRIM(customer_id)) AS customer_id,
# MAGIC       INITCAP(TRIM(customer_name)) AS customer_name,
# MAGIC       CASE
# MAGIC         WHEN TRIM(city) = '' THEN 'Unknown'
# MAGIC         ELSE INITCAP(TRIM(city))
# MAGIC       END AS city,
# MAGIC       state,
# MAGIC       region,
# MAGIC       customer_segment,
# MAGIC       is_active,
# MAGIC       TO_TIMESTAMP(updated_at) AS updated_at,
# MAGIC       ROW_NUMBER() OVER
# MAGIC       (
# MAGIC         PARTITION BY customer_id
# MAGIC         ORDER BY TO_TIMESTAMP(updated_at) DESC
# MAGIC       ) AS profile_rank
# MAGIC     FROM bronze_customers
# MAGIC   )
# MAGIC   WHERE profile_rank = 1
# MAGIC     AND is_active = 'Y'
# MAGIC ),
# MAGIC product_clean AS
# MAGIC (
# MAGIC   SELECT
# MAGIC     UPPER(TRIM(product_id)) AS product_id,
# MAGIC     INITCAP(TRIM(product_name)) AS product_name,
# MAGIC     INITCAP(TRIM(category)) AS category,
# MAGIC     subcategory,
# MAGIC     CAST(unit_price AS DECIMAL(12,2)) AS unit_price,
# MAGIC     CAST(cost_price AS DECIMAL(12,2)) AS cost_price
# MAGIC   FROM bronze_products
# MAGIC   WHERE active_flag = 'Y'
# MAGIC     AND CAST(unit_price AS DECIMAL(12,2)) IS NOT NULL
# MAGIC     AND CAST(cost_price AS DECIMAL(12,2)) IS NOT NULL
# MAGIC ),
# MAGIC order_clean AS
# MAGIC (
# MAGIC   SELECT
# MAGIC     UPPER(TRIM(order_id)) AS order_id,
# MAGIC     TO_TIMESTAMP(order_timestamp) AS order_timestamp,
# MAGIC     DATE_FORMAT(TO_TIMESTAMP(order_timestamp), 'yyyy-MM') AS order_month,
# MAGIC     UPPER(TRIM(customer_id)) AS customer_id,
# MAGIC     UPPER(TRIM(product_id)) AS product_id,
# MAGIC     CAST(quantity AS INT) AS quantity,
# MAGIC     COALESCE(CAST(discount_pct AS DOUBLE), 0.0) AS discount_pct,
# MAGIC     order_status,
# MAGIC     payment_method,
# MAGIC     sales_channel
# MAGIC   FROM bronze_sales_orders
# MAGIC   WHERE CAST(quantity AS INT) > 0
# MAGIC     AND order_status IN ('COMPLETED', 'RETURNED')
# MAGIC )
# MAGIC SELECT
# MAGIC   o.order_id,
# MAGIC   o.order_timestamp,
# MAGIC   o.order_month,
# MAGIC   o.customer_id,
# MAGIC   c.customer_name,
# MAGIC   c.city,
# MAGIC   c.state,
# MAGIC   c.region,
# MAGIC   c.customer_segment,
# MAGIC   o.product_id,
# MAGIC   p.product_name,
# MAGIC   p.category,
# MAGIC   p.subcategory,
# MAGIC   o.quantity,
# MAGIC   p.unit_price,
# MAGIC   p.cost_price,
# MAGIC   o.discount_pct,
# MAGIC   o.order_status,
# MAGIC   o.payment_method,
# MAGIC   o.sales_channel,
# MAGIC   ROUND(o.quantity * p.unit_price, 2) AS gross_amount,
# MAGIC   ROUND(
# MAGIC     o.quantity * p.unit_price * o.discount_pct / 100,
# MAGIC     2
# MAGIC   ) AS discount_amount,
# MAGIC   ROUND(
# MAGIC     o.quantity * p.unit_price *
# MAGIC     (1 - o.discount_pct / 100),
# MAGIC     2
# MAGIC   ) AS net_amount,
# MAGIC   CASE
# MAGIC     WHEN o.order_status = 'RETURNED'
# MAGIC       THEN -ROUND(
# MAGIC         o.quantity * p.unit_price *
# MAGIC         (1 - o.discount_pct / 100),
# MAGIC         2
# MAGIC       )
# MAGIC     ELSE ROUND(
# MAGIC       o.quantity * p.unit_price *
# MAGIC       (1 - o.discount_pct / 100),
# MAGIC       2
# MAGIC     )
# MAGIC   END AS net_sales
# MAGIC FROM order_clean o
# MAGIC INNER JOIN customer_latest c
# MAGIC   ON o.customer_id = c.customer_id
# MAGIC INNER JOIN product_clean p
# MAGIC   ON o.product_id = p.product_id;

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE TABLE sql_monthly_category_sales AS
# MAGIC SELECT
# MAGIC   order_month,
# MAGIC   category,
# MAGIC   COUNT(DISTINCT order_id) AS order_count,
# MAGIC   SUM(quantity) AS total_quantity,
# MAGIC   ROUND(SUM(net_sales), 2) AS total_revenue,
# MAGIC   ROUND(AVG(net_amount), 2) AS average_order_value,
# MAGIC   ROUND(MIN(net_amount), 2) AS minimum_order_value,
# MAGIC   ROUND(MAX(net_amount), 2) AS maximum_order_value
# MAGIC FROM sql_sales_enriched
# MAGIC GROUP BY order_month, category;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH product_revenue AS
# MAGIC (
# MAGIC   SELECT
# MAGIC     category,
# MAGIC     product_id,
# MAGIC     product_name,
# MAGIC     ROUND(SUM(net_sales), 2) AS product_revenue
# MAGIC   FROM sql_sales_enriched
# MAGIC   GROUP BY category, product_id, product_name
# MAGIC )
# MAGIC SELECT *
# MAGIC FROM
# MAGIC (
# MAGIC   SELECT
# MAGIC     *,
# MAGIC     RANK() OVER
# MAGIC     (
# MAGIC       PARTITION BY category
# MAGIC       ORDER BY product_revenue DESC
# MAGIC     ) AS product_rank
# MAGIC   FROM product_revenue
# MAGIC )
# MAGIC WHERE product_rank <= 5
# MAGIC ORDER BY category, product_rank;

# COMMAND ----------

# MAGIC %sql
# MAGIC WITH customer_value AS
# MAGIC (
# MAGIC   SELECT
# MAGIC     customer_id,
# MAGIC     customer_name,
# MAGIC     state,
# MAGIC     ROUND(SUM(net_sales), 2) AS customer_revenue
# MAGIC   FROM sql_sales_enriched
# MAGIC   GROUP BY customer_id, customer_name, state
# MAGIC )
# MAGIC SELECT *
# MAGIC FROM
# MAGIC (
# MAGIC   SELECT
# MAGIC     *,
# MAGIC     DENSE_RANK() OVER
# MAGIC     (
# MAGIC       PARTITION BY state
# MAGIC       ORDER BY customer_revenue DESC
# MAGIC     ) AS state_customer_rank
# MAGIC   FROM customer_value
# MAGIC )
# MAGIC WHERE state_customer_rank <= 3
# MAGIC ORDER BY state, state_customer_rank;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   order_month,
# MAGIC   category,
# MAGIC   total_revenue,
# MAGIC   ROUND(
# MAGIC     SUM(total_revenue) OVER
# MAGIC     (
# MAGIC       PARTITION BY category
# MAGIC       ORDER BY order_month
# MAGIC       ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
# MAGIC     ),
# MAGIC     2
# MAGIC   ) AS running_category_revenue
# MAGIC FROM sql_monthly_category_sales
# MAGIC ORDER BY category, order_month;

# COMMAND ----------

# MAGIC %sql
# MAGIC SELECT
# MAGIC   p.order_month,
# MAGIC   p.category,
# MAGIC   p.total_revenue AS pyspark_total,
# MAGIC   s.total_revenue AS sql_total,
# MAGIC   ROUND(p.total_revenue - s.total_revenue, 2) AS difference
# MAGIC FROM gold_monthly_category_sales p
# MAGIC INNER JOIN sql_monthly_category_sales s
# MAGIC   ON p.order_month = s.order_month
# MAGIC  AND p.category = s.category
# MAGIC ORDER BY p.order_month, p.category;
